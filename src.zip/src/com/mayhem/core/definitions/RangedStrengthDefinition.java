package com.mayhem.core.definitions;

public class RangedStrengthDefinition {

	private short id;

	private short bonus;

	public int getBonus() {
		return bonus;
	}

	public int getId() {
		return id;
	}

}
