package com.mayhem.core.definitions;

public class RangedDefinition {

	private short id;
	private short[] ammo;

	public short[] getAmmo() {
		return ammo;
	}

	public int getId() {
		return id;
	}
}
