package com.mayhem.core.task;

public enum TaskIdentifier {
	SPECIAL_RESTORE,
}
