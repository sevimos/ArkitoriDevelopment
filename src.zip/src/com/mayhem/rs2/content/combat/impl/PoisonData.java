package com.mayhem.rs2.content.combat.impl;

public class PoisonData {

	private final int start;

	public PoisonData(int start) {
		this.start = start;
	}

	public int getStart() {
		return start;
	}
}
