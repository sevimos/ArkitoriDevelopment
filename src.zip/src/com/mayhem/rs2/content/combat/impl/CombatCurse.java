package com.mayhem.rs2.content.combat.impl;

public class CombatCurse {

}
