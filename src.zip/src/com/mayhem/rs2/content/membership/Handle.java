package com.mayhem.rs2.content.membership;

import com.mayhem.rs2.entity.player.Player;

/**
 * @author Daniel
 */
public interface Handle {

	public void handle(Player player);

}
