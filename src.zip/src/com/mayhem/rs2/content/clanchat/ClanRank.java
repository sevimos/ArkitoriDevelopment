package com.mayhem.rs2.content.clanchat;

public class ClanRank {

	public static final int ANYONE = -1;
	public static final int FRIEND = 0;
	public static final int RECRUIT = 1;
	public static final int CORPORAL = 2;
	public static final int SERGEANT = 3;
	public static final int LIEUTENANT = 4;
	public static final int CAPTAIN = 5;
	public static final int GENERAL = 6;
	public static final int OWNER = 7;
	public static final int ADMINISTATOR = 8;
}