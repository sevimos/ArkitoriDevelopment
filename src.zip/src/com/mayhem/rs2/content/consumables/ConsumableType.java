package com.mayhem.rs2.content.consumables;

public enum ConsumableType {
	POTION, FOOD;
}
