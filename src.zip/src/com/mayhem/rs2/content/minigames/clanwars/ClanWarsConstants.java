package com.mayhem.rs2.content.minigames.clanwars;

import com.mayhem.rs2.entity.Location;

public class ClanWarsConstants {
	
	public static final Location CLAN_WARS_ARENA = new Location(3367, 3163, 0);
	
	public static final Location FFA_PORTAL = new Location(3327, 4751, 0);

}
