package com.mayhem.rs2.content.minigames.f2parena;

import com.mayhem.rs2.entity.Location;

public class F2PArenaConstants {
	
	public static final int[] ALLOWED_PRAYERS = {
			
	};
	
	public static final int[] ALLOWED_ITEMS = {
			
	};
	
	public static final Location[] RESPAWN_LOCATIONS = {
			
	};

}
