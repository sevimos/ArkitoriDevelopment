package com.mayhem.rs2.content.skill.crafting;

public enum CraftingType {

	LEATHER_TANNING, WHEEL_SPINNING;
}
