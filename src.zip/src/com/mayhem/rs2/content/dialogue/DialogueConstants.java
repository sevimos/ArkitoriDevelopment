package com.mayhem.rs2.content.dialogue;

public class DialogueConstants {

	public static final int OPTIONS_2_1 = 9157;
	public static final int OPTIONS_2_2 = 9158;
	public static final int OPTIONS_3_1 = 9167;
	public static final int OPTIONS_3_2 = 9168;
	public static final int OPTIONS_3_3 = 9169;
	public static final int OPTIONS_4_1 = 9178;
	public static final int OPTIONS_4_2 = 9179;
	public static final int OPTIONS_4_3 = 9180;
	public static final int OPTIONS_4_4 = 9181;
	public static final int OPTIONS_5_1 = 9190;
	public static final int OPTIONS_5_2 = 9191;
	public static final int OPTIONS_5_3 = 9192;
	public static final int OPTIONS_5_4 = 9193;
	public static final int OPTIONS_5_5 = 9194;
}
